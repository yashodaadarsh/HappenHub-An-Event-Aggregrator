package com.adarsh.EventIngestionService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventIngestionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventIngestionServiceApplication.class, args);
	}

}
